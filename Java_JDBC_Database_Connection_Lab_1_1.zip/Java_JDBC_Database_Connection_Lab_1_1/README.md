# OOPS Through Java Lab 1.1 — JDBC Database Connection

## AIM
Connect to MySQL using JDBC, retrieve all records from the `users` table, and display each user's ID, username, and email.

## Files
- `JDBCConnectionDemo.java` — Java JDBC program
- `setup.sql` — optional SQL to create the sample database/table and insert sample rows

## Before running
1. Make sure MySQL Server is running.
2. Run `setup.sql` in MySQL if you need the sample database/table.
3. In `JDBCConnectionDemo.java`, update `USERNAME` and `PASSWORD` for your MySQL account.
4. Add the MySQL Connector/J JDBC driver to your project's dependencies/classpath.

## Compile and run
If the MySQL Connector/J JAR is downloaded locally, replace `/path/to/mysql-connector-j.jar` with its actual path.

macOS/Linux:
```bash
javac -cp .:/path/to/mysql-connector-j.jar JDBCConnectionDemo.java
java -cp .:/path/to/mysql-connector-j.jar JDBCConnectionDemo
```

Windows:
```bat
javac -cp .;C:\path\to\mysql-connector-j.jar JDBCConnectionDemo.java
java -cp .;C:\path\to\mysql-connector-j.jar JDBCConnectionDemo
```

Alternatively, add MySQL Connector/J to your IDE project dependencies and run `JDBCConnectionDemo`.

## Example output
```text
Connected to the database successfully.
User ID: 1, Username: johndoe, Email: johndoe@example.com
User ID: 2, Username: janedoe, Email: janedoe@example.com
User ID: 3, Username: alice, Email: alice@example.com
```

Output depends on the actual records in your database. If connection details are wrong, the program prints an SQL error message.

## Algorithm
1. Import JDBC classes from `java.sql`.
2. Define the JDBC URL, username, and password.
3. Open a connection, statement, and result set using try-with-resources.
4. Execute `SELECT id, username, email FROM users`.
5. Loop through the results and print each record.
6. Catch `SQLException`; try-with-resources closes JDBC resources automatically.
